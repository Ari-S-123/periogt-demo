#!/bin/bash

python prepare_pt_dataset.py --data_path ../datasets/pretrain/